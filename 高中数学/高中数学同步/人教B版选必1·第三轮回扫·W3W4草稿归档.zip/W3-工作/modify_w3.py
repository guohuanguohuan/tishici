# -*- coding: utf-8 -*-
"""W3 讲部填空化改造（一次性脚本）。op:
  ('T', el, anchor, ans) 段内唯一锚 anchor，答案取其尾部 len(ans) 字符：拆run→插＿＿run＋答案run挂shd C9C9C9
  ('F', el, k)           段内第k个m:oMath（1基）前插＿＿run，oMath全部m:r与ctrlPr的w:rPr挂shd
  ('X', el, old, new)    §5纠错：段内m:t文本唯一替换
"""
import sys, zipfile, shutil, copy
from lxml import etree

W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
M = 'http://schemas.openxmlformats.org/officeDocument/2006/math'
def q(t): return '{%s}%s' % (W, t)
def mq(t): return '{%s}%s' % (M, t)
SHD = 'C9C9C9'
BLANK = '＿＿'

def wpr_shd(wpr):
    for shd in wpr.findall(q('shd')):
        wpr.remove(shd)
    s = etree.SubElement(wpr, q('shd'))
    s.set(q('val'), 'clear'); s.set(q('color'), 'auto'); s.set(q('fill'), SHD)

def para_text(p):
    out = []
    for t in p.iter(q('t')):
        anc, skip = t.getparent(), False
        while anc is not None and anc is not p:
            if anc.tag == mq('oMath') or anc.tag.endswith('}Fallback'):
                skip = True; break
            anc = anc.getparent()
        if not skip:
            out.append((t, t.text or ''))
    return out

def make_blank_run(rpr_src):
    r = etree.Element(q('r'))
    if rpr_src is not None:
        rp = copy.deepcopy(rpr_src)
        for shd in rp.findall(q('shd')):
            rp.remove(shd)
        r.append(rp)
    else:
        rp = etree.Element(q('rPr'))
        f = etree.SubElement(rp, q('rFonts'))
        f.set(q('ascii'), 'Times New Roman'); f.set(q('hAnsi'), 'Times New Roman')
        f.set(q('eastAsia'), '宋体')
        sz = etree.SubElement(rp, q('sz')); sz.set(q('val'), '21')
        szcs = etree.SubElement(rp, q('szCs')); szcs.set(q('val'), '21')
        r.append(rp)
    t = etree.SubElement(r, q('t'))
    t.text = BLANK
    t.set('{http://www.w3.org/XML/1998/namespace}space', 'preserve')
    return r

def op_text(p, pre, ans, post, log, fi, el):
    anchor = pre + ans + post
    ts = para_text(p)
    full = ''.join(x[1] for x in ts)
    assert full.count(anchor) == 1, '锚不唯一(%d) file%d el%d %r' % (full.count(anchor), fi, el, anchor)
    s = full.index(anchor) + len(pre)
    e = s + len(ans)
    assert full[s:e] == ans
    off, inserted = 0, False
    for t, txt in ts:
        o = off; off += len(txt)
        if o + len(txt) <= s or o >= e:
            continue
        run = t.getparent()
        parent = run.getparent()
        assert len(run.findall(q('t'))) == 1, 'run含多t el%d' % el
        pos = list(parent).index(run)
        a = max(s - o, 0); b = min(e - o, len(txt))
        pre_t, mid, post_t = txt[:a], txt[a:b], txt[b:]
        seq = ([('pre', pre_t)] if pre_t else []) + [('mid', mid)] + ([('post', post_t)] if post_t else [])
        newels = []
        for kind, txt2 in seq:
            r = copy.deepcopy(run)
            r.find(q('t')).text = txt2
            if kind == 'mid':
                wpr = r.find(q('rPr'))
                if wpr is None:
                    wpr = etree.Element(q('rPr')); r.insert(0, wpr)
                wpr_shd(wpr)
            newels.append(r)
        parent.remove(run)
        for i, r in enumerate(newels):
            parent.insert(pos + i, r)
        if not inserted:
            mid_el = newels[1] if pre_t else newels[0]
            mid_el.addprevious(make_blank_run(mid_el.find(q('rPr'))))
            inserted = True
    assert inserted, '未插入 el%d' % el
    log.append(('T', fi, el, ans))

def op_formula(p, k, log, fi, el):
    oms = p.findall('.//' + mq('oMath'))
    assert len(oms) >= k, 'oMath#%d不存在 el%d（实有%d）' % (k, el, len(oms))
    om = oms[k - 1]
    rpr_src = None
    for child in p:
        if child is om:
            break
        if child.tag == q('r') and ''.join(x.text or '' for x in child.findall(q('t'))).strip():
            rpr_src = child.find(q('rPr'))
    om.addprevious(make_blank_run(rpr_src))
    n = 0
    for mr in om.iter(mq('r')):
        wpr = mr.find(q('rPr'))
        if wpr is None:
            wpr = etree.Element(q('rPr')); mr.insert(0, wpr)
        wpr_shd(wpr); n += 1
    for cp in om.iter(mq('ctrlPr')):
        wpr = cp.find(q('rPr'))
        if wpr is None:
            wpr = etree.SubElement(cp, q('rPr'))
        wpr_shd(wpr); n += 1
    log.append(('F', fi, el, 'oMath#%d(挂点%d)' % (k, n)))

def op_fix(p, old, new, log, fi, el):
    hits = [t for t in p.iter(mq('t')) if t.text and old in t.text]
    assert len(hits) == 1, '纠错锚不唯一(%d) el%d' % (len(hits), el)
    hits[0].text = hits[0].text.replace(old, new)
    log.append(('X', fi, el, '%s→%s' % (old, new)))

F1 = '人教B版选必1 第1章 空间向量与立体几何（上）·讲练件（61题）.docx'
F2 = '人教B版选必1 第1章 空间向量与立体几何（下）·讲练件（79题）.docx'
F3 = '人教B版选必1 第1章 空间向量与立体几何·衔接件（29题）.docx'
OPS = {
 1: [  # B 上卷（讲部1: 405-418；讲部2: 485-491；讲部3: 607-639）
  ('T', 409, '各个面的', '交点、交线', ''),
  ('T', 412, '截线必须', '首尾相接', ''),
  ('T', 415, '利用', '平行或共点', '关系补线'),
  ('T', 416, '再求', '球心', '到截平面的距离'),
  ('T', 418, '', '找截点', '→连线'),
  ('T', 486, '问题时，', '三余弦定理', '可以帮助'),
  ('F', 489, 3, None),
  ('T', 491, '特点：', '连续两次投影', ''),
  ('F', 609, 4, None),
  ('F', 609, 6, None),
  ('T', 612, '两向量的夹角', '互补', ''),
  ('T', 613, '两向量的夹角', '相等', ''),
  ('T', 614, '总结规律（', '同负异正', '）'),
  ('T', 620, '从而得名：', '同等异补', ''),
  ('T', 624, '，', '无需判断锐钝', ''),
  ('T', 625, '两法向量的夹角', '或其补角', ''),
  ('T', 634, '建议采用“', '先证后用', '”的方式'),
 ],
 2: [  # C 下卷（讲部1: 36-57；2: 170-176；3: 195-203；4: 217-223；5: 344-363；6: 833-836）
  ('T', 38, '——', '补形法与双外心模型', ''),
  ('T', 40, '补形成', '直棱柱', ''),
  ('T', 42, '又称', '墙角模型', ''),
  ('T', 44, '垂足为三角形的', '非直角顶点', ''),
  ('T', 46, '两个面的', '面对角线', ''),
  ('T', 51, '长方体”为', '载体', ''),
  ('T', 53, '长方体的', '体对角线', '长'),
  ('T', 171, '以“', '直三棱柱、圆柱', '”为载体'),
  ('T', 173, '用', '找球心法', '('),
  ('T', 173, '外心O2', '连线的中点', ''),
  ('T', 196, '有一侧面', '垂直底面', '的棱锥型'),
  ('T', 199, '交点O即为', '球心', ''),
  ('T', 200, '为两个面的', '外接圆的半径', ''),
  ('T', 219, '两个面的', '外心', ''),
  ('T', 222, '通过连接', '公共边的中点', ''),
  ('T', 346, '刚好卡住的', '临界情况', ''),
  ('F', 348, 4, None),
  ('T', 350, '②', '平面化', '：'),
  ('T', 356, '方法：', '等体积法', ''),
  ('F', 362, 2, None),
  ('T', 835, '某一图形的', '基本定义', ''),
  ('T', 836, '求出动点的', '轨迹方程', ''),
 ],
 3: [  # X1 衔接件条目直挂（1.2.1: 3-38；1.2.5: 151-175）
  ('T', 4, '截得的对应线段', '成比例', ''),
  ('T', 18, '周长的比等于', '相似比', ''),
  ('T', 19, '相似比的', '平方', ''),
  ('F', 25, 1, None), ('F', 25, 2, None), ('F', 25, 3, None),
  ('F', 34, 4, None),
  ('F', 37, 5, None),
  ('T', 152, '三条', '中线', '相交于一点'),
  ('T', 155, '每条中线的', '三等分点', ''),
  ('X', 155, 'BO=2DF', 'BO=2OF'),
  ('T', 157, '三条', '角平分线', '相交于一点'),
  ('T', 160, '到三角形的', '三边', '的距离相等'),
  ('T', 163, '三条', '高', '所在直线'),
  ('T', 165, '在三角形的', '内部', '，直角三角形'),
  ('T', 168, '三边的', '垂直平分线', ''),
  ('T', 171, '到', '三个顶点', '的距离相等'),
  ('T', 174, '高线）', '合一', ''),
  ('T', 175, '正三角形的', '中心', ''),
 ],
}
FILES = {1: F1, 2: F2, 3: F3}

def main(apply_mode):
    log = []
    for fi in (1, 2, 3):
        path = FILES[fi]
        with zipfile.ZipFile(path) as z:
            doc = etree.fromstring(z.read('word/document.xml'))
        body = doc.find(q('body'))
        els = list(body)
        for op in OPS[fi]:
            p = els[op[1]]
            if op[0] == 'T':
                op_text(p, op[2], op[3], op[4], log, fi, op[1])
            elif op[0] == 'F':
                op_formula(p, op[2], log, fi, op[1])
            else:
                op_fix(p, op[2], op[3], log, fi, op[1])
        print('file%d %s ops=%d' % (fi, path[:20], len(OPS[fi])))
        if apply_mode:
            xml = etree.tostring(doc, xml_declaration=True, encoding='UTF-8', standalone=True)
            with zipfile.ZipFile(path) as zin, zipfile.ZipFile(path + '.new', 'w', zipfile.ZIP_DEFLATED) as zout:
                for item in zin.infolist():
                    data = zin.read(item.filename)
                    if item.filename == 'word/document.xml':
                        data = xml
                    zout.writestr(item, data)
            shutil.move(path + '.new', path)
    print('TOTAL ops =', len(log))
    for x in log:
        print(x)

if __name__ == '__main__':
    main(len(sys.argv) > 1 and sys.argv[1] == 'apply')
