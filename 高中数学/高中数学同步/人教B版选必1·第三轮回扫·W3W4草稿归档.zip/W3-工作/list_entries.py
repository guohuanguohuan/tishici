# -*- coding: utf-8 -*-
# 列出 docx 全部条目题名行（「N．」开头）与节标题，用于豁免判据
import sys, zipfile, re
import xml.etree.ElementTree as ET
W='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
M='{http://schemas.openxmlformats.org/officeDocument/2006/math}'
MC='{http://schemas.openxmlformats.org/markup-compatibility/2006}'
def lin(el):
    toks=[]
    def walk(e):
        if e.tag==MC+'Fallback': return
        if e.tag==M+'oMath': toks.append('⟦F⟧'); return
        if e.tag==W+'t': toks.append(e.text or ''); return
        if e.tag in (W+'tab',W+'br'): toks.append(' '); return
        for c in e: walk(c)
    walk(el); return ''.join(toks)
path=sys.argv[1]
with zipfile.ZipFile(path) as z: root=ET.fromstring(z.read('word/document.xml'))
body=root.find(W+'body')
for i,e in enumerate(body):
    if e.tag!=W+'p': continue
    t=lin(e).strip()
    if re.match(r'^\d{1,2}．\S',t) or re.match(r'^\d+\.\d+(\.\d+)*\s',t):
        print(i,t[:80])
