# -*- coding: utf-8 -*-
import sys, zipfile, re
import xml.etree.ElementTree as ET
W='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
M='{http://schemas.openxmlformats.org/officeDocument/2006/math}'
MC='{http://schemas.openxmlformats.org/markup-compatibility/2006}'
def lin(el):
    toks=[]
    def walk(e):
        if e.tag==MC+'Fallback': return
        if e.tag==M+'oMath': toks.append('⟦F⟧'); return
        if e.tag==W+'t': toks.append(e.text or ''); return
        if e.tag in (W+'tab',W+'br'): toks.append(' '); return
        if e.tag==W+'drawing': toks.append('⟦图⟧'); return
        for c in e: walk(c)
    walk(el); return ''.join(toks)
def shd_count(el):
    return len(el.findall('.//'+W+'shd'))
path=sys.argv[1]; lo=int(sys.argv[2]); hi=int(sys.argv[3])
with zipfile.ZipFile(path) as z:
    root=ET.fromstring(z.read('word/document.xml'))
body=root.find(W+'body')
els=list(body)
for i in range(lo,min(hi,len(els))):
    e=els[i]; tag=e.tag.replace(W,'w:')
    t=lin(e).strip()
    nshd=len(e.findall('.//'+W+'shd'))
    print('%d\t%s\tshd=%d\t%s'%(i,tag,nshd,t[:90] if tag!='w:tbl' else '[TABLE %d行 内段%d]'%(len(e.findall('.//'+W+'tr')),len(e.findall('.//'+W+'p')))))
